# Learn with Roby · DSK AI Coach

Student site for Dubai Schools Al Khawaneej: 135 Unit 2 activities (Grades 6, 7 and 8), each with Roby's step-by-step lesson, sounds, a male robot voice and the interactive board.

Each activity has its own link: `https://mzahwi-ctrl.github.io/roby/#s-<activity>` (the QR codes in DSK Fluid Activities use these links).

To add a unit later: add its file to `units/` and list it in `units/manifest.js`.
