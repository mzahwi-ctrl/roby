/* Integrated Math II · Savvas enVision Integrated Mathematics II
   Topic 1 has full fluid activities. The other topics list their lessons; activities are added topic by topic.
   Course order follows the book: Topics 1-6, then Math I Topics 8 and 9, then Math II Topics 7, 8 and 9. */
ARENA.unit({grade:'IM2',unit:1,tag:'Topic 1',title:'Exponents and Roots',lessons:[

{code:'1-1',mod:'Topic 1 · Exponents and Roots',title:'Operations on Real Numbers',acts:[
 {id:'im2t1-1-1a',t:'Rational or irrational? Test the results',min:7,eng:'expr',
  life:'A tiler cuts square tiles with side √2 dm. Some products and sums of roots come out rational, and some do not.',
  cfg:{steps:[{e:'√2 · √8 = √16 = 4',note:'Product of two irrationals: here the answer is RATIONAL.',hl:'4'},{e:'√2 + √2 = 2√2',note:'Sum of two irrationals: here it stays IRRATIONAL.'},{e:'3 + √5',note:'Rational + irrational is ALWAYS irrational.'},{e:'½ · 0.6 = 0.3',note:'Rational × rational is ALWAYS rational: the rationals are closed.'},{e:'4 · √3 = 4√3',note:'Non-zero rational × irrational is ALWAYS irrational.'}]},
  ask:['Which results are always rational? Which only sometimes?','Find two irrationals whose sum is rational.','Is √9 rational or irrational? Why?','What does “closed under multiplication” mean?'],
  ch:{q:'Classify: √3 · √12,  √3 + √12,  5 − √7.',a:'√36 = 6 rational; √3 + 2√3 = 3√3 irrational; 5 − √7 irrational.'}},
 {id:'im2t1-1-1b',t:'Turn 0.272727… into a fraction',min:6,eng:'expr',
  life:'Every repeating decimal is rational. A shop’s calculator shows 0.272727…; algebra finds the exact fraction.',
  cfg:{steps:[{e:'x = 0.272727…',note:'Let x be the repeating decimal. Two digits repeat.'},{e:'100x = 27.272727…',note:'Multiply by 100 to move one full repeat to the left.',hl:'100x'},{e:'100x − x = 27.2727… − 0.2727…',note:'Subtract: the repeating parts cancel.'},{e:'99x = 27',note:'The decimals are gone.'},{e:'x = 27/99 = 3/11',note:'Divide by 99 and simplify by 9.'},{e:'Check: 3 ÷ 11 = 0.272727… ✓',note:'Divide on a calculator.'}]},
  ask:['Why multiply by 100 and not by 10?','What would you multiply by for 0.444…?','Why does subtracting make the repeating part disappear?','Is every repeating decimal rational? Explain.'],
  ch:{q:'Write 0.555… as a fraction.',a:'10x − x = 5, so 9x = 5 and x = 5/9.'}},
 {id:'im2t1-1-1c',t:'Spot the mistake: the sum of a rational and an irrational',min:6,eng:'expr',
  life:'Two students try to explain why 2 + √3 is irrational. Proof by contradiction shows it in a few lines.',
  cfg:{steps:[{e:'Suppose 2 + √3 = r, where r is rational',note:'Assume the opposite of what we want to show.'},{e:'√3 = r − 2',note:'Subtract 2 from both sides.'},{e:'r − 2 is rational',note:'A rational minus a rational is rational.'},{e:'So √3 is rational: impossible!',note:'√3 is irrational, so the assumption was false. 2 + √3 is irrational.'}],rightName:'Maryam',compare:{name:'Khalid',steps:[{e:'2 + √3 ≈ 3.732'},{e:'3.732 is a decimal'},{e:'so 2 + √3 is irrational'}]}},
  ask:['Why is Khalid’s reasoning not enough?','Is 3.732 rational or irrational?','What does “contradiction” mean in Maryam’s proof?','Use the same idea to show 5√2 is irrational.'],
  ch:{q:'Is π − π rational or irrational? What does this tell you?',a:'π − π = 0 is rational: the difference of two irrationals can be rational.'}}
],roby:[
 {say:'Rational numbers can be written as a fraction of integers. Irrational numbers cannot.',vis:{t:'tab',h:['Rational','Irrational'],r:[['3/11','√2'],['0.2727…','π'],['√16 = 4','2 + √3']]}},
 {say:'Rational with rational gives rational. Rational with irrational gives irrational.',vis:{t:'eq',l:['½ + 0.3 = 0.8  rational','3 + √5  irrational']}},
 {say:'Two irrationals can give either.',vis:{t:'eq',l:['√2 · √8 = 4  rational','√2 + √2 = 2√2  irrational']}}
]},

{code:'1-2',mod:'Topic 1 · Exponents and Roots',title:'Rational Exponents and Properties of Exponents',acts:[
 {id:'im2t1-1-2a',t:'What does 8^(2/3) mean?',min:7,eng:'expr',
  life:'A cube-shaped water tank holds 8 m³. Its side is 8^(1/3) = 2 m, and one face has area 8^(2/3) = 4 m².',
  cfg:{steps:[{e:'8^(1/3) = ∛8 = 2',note:'The denominator 3 means cube root.'},{e:'8^(2/3) = (8^(1/3))²',note:'The numerator 2 means square it.',hl:'(8^(1/3))²'},{e:'= 2² = 4',note:'Take the root first: smaller numbers are easier.'},{e:'27^(−2/3) = 1 / 27^(2/3)',note:'A negative exponent means reciprocal.'},{e:'= 1 / (∛27)² = 1 / 3² = 1/9',note:'Root, then power, then reciprocal.'}]},
  ask:['What does the denominator of the exponent tell you?','Why is it easier to take the root first?','Show that 8^(2/3) = ∛(8²) gives the same answer.','What is 16^(3/4)?'],
  ch:{q:'Evaluate 32^(3/5) and 9^(−1/2).',a:'(⁵√32)³ = 2³ = 8; 1/√9 = 1/3.'}},
 {id:'im2t1-1-2b',t:'The exponent laws still work',min:6,eng:'expo',
  life:'The laws you learned for whole-number exponents also work for rational exponents. Explore them again, then try them with fractions.',
  cfg:{mode:'product',modes:['product','quotient','power'],b:'x',m:4,n:2,say:'Choose a law. Change m and n. Predict the new exponent, then press Show the law.'},
  ask:['Which law adds, which subtracts, which multiplies the exponents?','Use the product law: x^(1/2) · x^(1/2) = ?','Use the power law: (x^(2/3))³ = ?','Why does x^(1/2) mean √x?'],
  ch:{q:'Simplify x^(1/3) · x^(2/3) and (x^(1/4))⁸.',a:'x^(3/3) = x and x^(8/4) = x².'}},
 {id:'im2t1-1-2c',t:'Simplify (16x⁸)^(3/4)',min:7,eng:'expr',
  life:'Scientists simplify expressions with rational exponents before they calculate. Apply the power to every factor.',
  cfg:{steps:[{e:'(16x⁸)^(3/4)',note:'A power of a product: apply 3/4 to 16 AND to x⁸.'},{e:'16^(3/4) · (x⁸)^(3/4)',note:'Power of a product.',hl:'16^(3/4)'},{e:'(⁴√16)³ · x^(8·3/4)',note:'Root then power for 16; multiply the exponents for x.'},{e:'2³ · x⁶',note:'⁴√16 = 2 and 8 · 3/4 = 6.'},{e:'8x⁶',note:'Simplified.'},{e:'Check with x = 1: (16)^(3/4) = 8 ✓',note:'A quick check with an easy value.'}]},
  ask:['Why does the 3/4 apply to both factors?','What is 8 · 3/4?','What mistake gives 12x⁶?','Simplify (27y⁶)^(2/3).'],
  ch:{q:'Simplify (81a¹²)^(1/4).',a:'3a³'}}
],roby:[
 {say:'In a rational exponent, the denominator is the root and the numerator is the power.',vis:{t:'big',s:'a^(m/n) = (ⁿ√a)ᵐ'}},
 {say:'Take the root first, then the power.',vis:{t:'eq',l:['8^(2/3) = (∛8)²','= 2²','= 4']}},
 {say:'All the exponent laws still work with fractions.',vis:{t:'eq',l:['x^(1/2) · x^(1/2) = x¹','(x^(2/3))³ = x²','x^(−1/2) = 1/√x']}}
]},

{code:'1-3',mod:'Topic 1 · Exponents and Roots',title:'Exponential Models',acts:[
 {id:'im2t1-1-3a',t:'Savings that grow: y = a(1 + r)^x',min:8,eng:'fx',
  life:'AED 1,000 in a savings account earning 6% a year grows to 1000(1.06)^x after x years. The growth gets faster every year.',
  cfg:{fs:[{f:'a*(1+r)^x',s:'y = a(1 + r)^x',n:'savings (AED)'}],params:[{k:'a',l:'starting amount (AED)',min:500,max:5000,step:500,v:1000},{k:'r',l:'rate per year',min:0.01,max:0.15,step:0.01,v:0.06}],
   xmin:0,xmax:20,ymin:0,ymax:20000,x0:10,tstep:1,xL:'years',yL:'AED',dp:2,   out:[{l:'After x years:  y = ',f:'a*(1+r)^x'},{l:'Gain so far (AED): ',f:'a*(1+r)^x-a'},{l:'Rule of 72: doubles in about (years) ',f:'72/(100*r)'}],
   say:'Change the rate. Watch how quickly the savings grow. Trace with the years slider.'},
  ask:['After 10 years at 6%, how much is there?','Why is the graph a curve and not a line?','Double the rate. Does the money after 10 years double?','How would the graph look for a rate of 0%?'],
  ch:{q:'AED 2,000 grows at 5% a year. Write the model and find the value after 3 years.',a:'y = 2000(1.05)^x; after 3 years y = 2000(1.157625) = AED 2,315.25.'}},
 {id:'im2t1-1-3b',t:'A new car loses value',min:7,eng:'fx',
  life:'A new car costs AED 80,000 and loses 15% of its value every year: y = 80000(0.85)^x. Decay factors are between 0 and 1.',
  cfg:{fs:[{f:'80000*b^x',s:'y = 80000 · b^x',n:'value (AED)'}],params:[{k:'b',l:'decay factor b',min:0.6,max:0.98,step:0.01,v:0.85}],
   xmin:0,xmax:10,ymin:0,ymax:85000,x0:5,tstep:1,xL:'years',yL:'AED',dp:0,
   out:[{l:'Percent lost each year: ',f:'(1-b)*100'},{l:'Value now (AED): ',f:'80000*b^x'}],
   say:'Move the decay factor. b = 0.85 means the car keeps 85% of its value each year.'},
  ask:['What is the value after 5 years?','How is the decay factor linked to the 15%?','Does the value ever reach zero? Why not?','Which b gives the fastest loss?'],
  ch:{q:'A phone worth AED 3,000 loses 20% a year. Write the model and find its value after 2 years.',a:'y = 3000(0.8)^x; after 2 years y = AED 1,920.'}},
 {id:'im2t1-1-3c',t:'Monthly interest: A = P(1 + r/n)^(nt)',min:7,eng:'expr',
  life:'Banks often add interest every month. AED 5,000 at 4% a year, added monthly for 3 years.',
  cfg:{steps:[{e:'A = P(1 + r/n)^(nt)',note:'P = 5000, r = 0.04, n = 12 times a year, t = 3 years.'},{e:'A = 5000(1 + 0.04/12)^(12·3)',note:'Substitute.',hl:'0.04/12'},{e:'A = 5000(1.00333…)^36',note:'Rate per month, and 36 months.'},{e:'A ≈ 5000(1.12727)',note:'Use a calculator for the power.'},{e:'A ≈ AED 5,636.36',note:'About AED 636 of interest.'},{e:'Yearly instead: 5000(1.04)³ = AED 5,624.32',note:'Monthly interest gives a little more.'}]},
  ask:['What do n and t stand for?','Why is the exponent 36?','Why does monthly interest give more than yearly?','What would n be for daily interest?'],
  ch:{q:'AED 2,000 at 6% a year, added every 3 months (quarterly), for 2 years. Write the expression.',a:'A = 2000(1 + 0.06/4)^(4·2) = 2000(1.015)⁸ ≈ AED 2,252.99.'}}
],roby:[
 {say:'An exponential model has a starting value and a constant factor.',vis:{t:'big',s:'y = a · bˣ'}},
 {say:'Growth: b is greater than 1. Decay: b is between 0 and 1.',vis:{t:'tab',h:['Story','Factor b'],r:[['grows 6% a year','1.06'],['loses 15% a year','0.85']]}},
 {say:'Each year we multiply by the same factor.',vis:{t:'tab',h:['Year','Savings (AED)'],r:[['0','1,000'],['1','1,060'],['2','1,123.60'],['10','≈ 1,790.85']]}}
]},

{code:'TN-2',mod:'Topic 1 · Exponents and Roots',title:'Comparing Properties of Functions',acts:[
 {id:'im2t1-TN-2a',t:'Linear or exponential: which wins?',min:7,eng:'fx',
  life:'Two new social media accounts: L starts with 3 thousand followers and gains 2 thousand a month; E starts with 1 thousand and doubles every month. Who is ahead?',
  cfg:{fs:[{f:'3+2*x',s:'L(x) = 3 + 2x',n:'L(x)'},{f:'2^x',s:'E(x) = 2ˣ',n:'E(x)'}],params:[],xmin:0,xmax:7,ymin:0,ymax:80,x0:1,tstep:0.5,dp:2,btn:'Show where E overtakes L',pts:[['3.25','3+2*3.25','E passes L']],xL:'months',yL:'thousand followers',
   out:[{l:'L(x) − E(x) = ',f:'3+2*x-2^x'}],
   say:'Trace from x = 0 to x = 7. Which function is ahead at the start? Which is ahead at the end?'},
  ask:['Which has the greater y-intercept?','Which has a constant rate of change?','Between which whole numbers does E overtake L?','Will a linear function always be overtaken by an increasing exponential one?'],
  ch:{q:'f(x) = 10x + 5 and g(x) = 3ˣ. Which is greater at x = 2? At x = 4?',a:'x = 2: f = 25, g = 9, so f. x = 4: f = 45, g = 81, so g.'}},
 {id:'im2t1-TN-2b',t:'An equation versus a table',min:6,eng:'expr',
  life:'Functions arrive in different forms: an equation, a table, a graph. Compare them by the same properties.',
  cfg:{steps:[{e:'f(x) = 3x + 1',note:'Function f is given by an equation.'},{e:'g: (0, 4), (1, 6), (2, 8)',note:'Function g is given by a table.'},{e:'Rate of change: f → 3,  g → (6 − 4)/(1 − 0) = 2',note:'Compare the slopes: f increases faster.'},{e:'y-intercept: f(0) = 1,  g(0) = 4',note:'g starts higher.'},{e:'Equal when 3x + 1 = 2x + 4 → x = 3',note:'g(x) = 2x + 4. After x = 3, f is greater.'}]},
  ask:['How do you find the rate of change from a table?','Which function is greater at x = 1? At x = 5?','Write an equation for g.','Sketch both functions on the same axes.'],
  ch:{q:'h(x) = −2x + 9. Table k: (0, 1), (2, 5). Compare rates of change and y-intercepts.',a:'h: rate −2, intercept 9. k: rate 2, intercept 1.'}}
],roby:[
 {say:'To compare functions, look at the same properties.',vis:{t:'tab',h:['Property','Linear','Exponential'],r:[['rate of change','constant','grows'],['y-intercept','3','1']]}},
 {say:'A linear function adds the same amount. An exponential function multiplies by the same factor.',vis:{t:'tab',h:['x','3 + 2x','2ˣ'],r:[['0','3','1'],['2','7','4'],['4','11','16'],['6','15','64']]}},
 {say:'An increasing exponential function eventually overtakes any linear function.',vis:{t:'ans',s:'Exponential growth always wins in the end.'}}
]},

{code:'1-4',mod:'Topic 1 · Exponents and Roots',title:'The Square Root Function',acts:[
 {id:'im2t1-1-4a',t:'Transform y = a√(x − h) + k',min:8,eng:'fx',
  life:'The square root graph starts at a point and curves gently. h and k move the starting point; a stretches or flips it.',
  cfg:{fs:[{f:'a*sqrt(x-h)+k',s:'y = a√(x − h) + k'},{f:'sqrt(x)',s:'parent: y = √x',dash:true}],params:[{k:'a',l:'a (stretch) =',min:-3,max:3,step:0.5,v:1},{k:'h',l:'h (left/right) =',min:-4,max:4,step:1,v:2},{k:'k',l:'k (up/down) =',min:-4,max:4,step:1,v:1}],
   xmin:-5,xmax:12,ymin:-8,ymax:10,btn:'Show the starting point',pts:[['h','k','start (#x, #y)']],
   out:[{l:'Domain:  x ≥ ',f:'h'},{l:'Starting value of y = ',f:'k'}],
   say:'Move h, k and a. Where does the graph start? Make a negative: what happens to the range?'},
  ask:['How do h and k move the starting point?','What is the domain? Why can x not be less than h?','What does a negative a do to the graph and the range?','Write the equation of a square root graph that starts at (−3, 2).'],
  ch:{q:'Find the domain and range of y = −2√(x + 1) + 5.',a:'Domain x ≥ −1; range y ≤ 5.'}},
 {id:'im2t1-1-4b',t:'Drop from the observation deck',min:7,eng:'fx',
  life:'Ignoring air resistance, an object dropped from d metres falls for t = √(d / 4.9) seconds. The Burj Khalifa observation deck is about 555 m high.',
  cfg:{fs:[{f:'sqrt(x/4.9)',s:'t = √(d / 4.9)',n:'time t (s)'}],params:[],xmin:0,xmax:600,ymin:0,ymax:12,x0:555,tstep:5,v:'d',xL:'height d (m)',yL:'time (s)',dp:2,
   say:'Slide the height. Does doubling the height double the time?'},
  ask:['How long does a fall from 555 m take?','Compare 100 m and 400 m. Is the time 4 times longer?','Why does the graph get flatter?','What height gives a fall of exactly 5 seconds?'],
  ch:{q:'An object falls for 3 seconds. From what height was it dropped?',a:'3 = √(d/4.9), so 9 = d/4.9 and d = 44.1 m.'}},
 {id:'im2t1-1-4c',t:'Average rate of change of √x',min:6,eng:'expr',
  life:'The average rate of change tells us how fast a function grows over an interval. For √x it keeps getting smaller.',
  cfg:{steps:[{e:'rate = (f(b) − f(a)) / (b − a)',note:'Change in y divided by change in x.'},{e:'4 to 9:  (√9 − √4)/(9 − 4) = (3 − 2)/5 = 0.2',note:'Interval [4, 9].'},{e:'9 to 16:  (√16 − √9)/(16 − 9) = 1/7 ≈ 0.14',note:'Interval [9, 16]: smaller.'},{e:'16 to 25:  (5 − 4)/9 ≈ 0.11',note:'Smaller again.'},{e:'The square root function grows more and more slowly',note:'The graph gets flatter as x increases.'}]},
  ask:['What is the average rate of change from 0 to 1?','Why does the rate get smaller?','How is this different from a linear function?','Find the rate from 1 to 4.'],
  ch:{q:'Find the average rate of change of f(x) = √x from x = 25 to x = 36.',a:'(6 − 5)/(36 − 25) = 1/11 ≈ 0.09.'}}
],roby:[
 {say:'The parent square root function starts at the origin.',vis:{t:'tab',h:['x','√x'],r:[['0','0'],['1','1'],['4','2'],['9','3']]}},
 {say:'h moves the graph left or right, k moves it up or down.',vis:{t:'eq',l:['y = a√(x − h) + k','start at (h, k)']}},
 {say:'The domain starts at h, because we cannot take the square root of a negative number.',vis:{t:'ans',s:'Domain: x ≥ h'}}
]}
]});

/* ---------------- lesson lists for the other topics ---------------- */
{
const T=(unit,tag,title,list)=>ARENA.unit({grade:'IM2',unit,tag,title,lessons:list.map(([code,t])=>({code,mod:tag+' · '+title,title:t,acts:[]}))});
T(2,'Topic 2','Polynomials and Factoring',[['2-1','Adding and Subtracting Polynomials'],['2-2','Multiplying Polynomials'],['2-3','Multiplying Special Cases'],['2-4','Factoring Polynomials'],['2-5','Factoring x² + bx + c'],['2-6','Factoring ax² + bx + c'],['2-7','Factoring Special Cases']]);
T(3,'Topic 3','Quadratic Functions',[['3-1','Key Features of Graphs of Quadratic Functions'],['3-2','Quadratic Functions in Vertex Form'],['3-3','Quadratic Functions in Standard Form'],['3-4','Modeling With Quadratic Functions'],['3-5','Comparing Linear, Exponential, and Quadratic Models'],['TN-1','Understanding Geometric Formulas as Functions']]);
T(4,'Topic 4','Solving Quadratic Equations',[['4-1','Solving Quadratic Equations Using Graphs and Tables'],['4-2','Solving Quadratic Equations by Factoring'],['4-3','Rewriting Radical Expressions'],['4-4','Solving Quadratic Equations Using Square Roots'],['4-5','Solving Systems of Linear and Quadratic Equations'],['TN-3','Solving Quadratic Inequalities by Graphing']]);
T(5,'Topic 5','Quadratic Equations and Complex Numbers',[['5-1','Complex Numbers and Operations'],['5-2','Completing the Square'],['5-3','The Quadratic Formula'],['5-4','Linear-Quadratic Systems'],['5-5','Polynomial Identities']]);
T(6,'Topic 6','Working With Functions',[['6-1','The Absolute Value Function'],['6-2','Piecewise-Defined Functions'],['6-3','Step Functions'],['6-4','Transformations of Piecewise-Defined Functions'],['6-5','Analyzing Functions Graphically'],['6-6','Translations of Functions'],['6-7','Compressions and Stretches of Functions'],['6-8','Operations With Functions'],['6-9','Inverse Functions'],['4-4 (M3)','Solving Radical Equations (Math III)']]);
T(7,'Topic 8 · Math I','Transformations',[['8-1','Reflections'],['8-2','Translations'],['8-3','Rotations'],['8-4','Classification of Rigid Motions'],['8-5','Symmetry']]);
T(8,'Topic 9 · Math I','Triangle Congruence',[['9-1','Congruence'],['9-3','Proving and Applying the SAS and SSS Congruence Criteria'],['9-4','Proving and Applying the ASA and AAS Congruence Criteria'],['9-5','Congruence in Right Triangles'],['9-6','Congruence in Overlapping Triangles'],['9-7','Polygons in the Coordinate Plane'],['9-8','Chords']]);
T(9,'Topic 7','Relationships in Triangles',[['7-1','Writing Proofs'],['7-2','Parallel Lines'],['7-5','Medians and Altitudes'],['7-6','Inequalities in One Triangle'],['7-7','Inequalities in Two Triangles']]);
T(10,'Topic 8','Quadrilaterals and Other Polygons',[['8-1','The Polygon Angle-Sum Theorems'],['8-2','Kites and Trapezoids'],['8-3','Properties of Parallelograms'],['8-4','Proving a Quadrilateral Is a Parallelogram'],['8-5','Properties of Special Parallelograms'],['8-6','Conditions of Special Parallelograms']]);
T(11,'Topic 9','Similarity and Right Triangles',[['9-1','Dilations'],['9-2','Similarity Transformations'],['9-3','Proving Triangles Similar'],['9-4','Similarity in Right Triangles'],['9-5','Proportions in Triangles']]);
}
