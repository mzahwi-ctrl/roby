/* Integrated Math I · Savvas enVision Integrated Mathematics I
   Topic 1 has full fluid activities. The other topics list their lessons; activities are added topic by topic. */
ARENA.unit({grade:'IM1',unit:1,tag:'Topic 1',title:'Solving Equations and Inequalities',lessons:[

{code:'1-1',mod:'Topic 1 · Solving Equations and Inequalities',title:'Solving Linear Equations',acts:[
 {id:'im1t1-1-1a',t:'Gold souq bracelets on the scale',min:7,eng:'balance',
  life:'In the Deira Gold Souq, 4 equal bracelets and a 6 g chain weigh 30 g on the jeweller’s scale: 4x + 6 = 30.',
  cfg:{p:4,q:6,r:30,bag:'bracelet',unit:'g',gmax:10,say:'Guess the mass of one bracelet with the slider, or solve it step by step. Keep the scale balanced.'},
  ask:['Which operation do we undo first? Why?','What does “do the same to both sides” keep true?','Check your answer on the scale.','Write a scale story for 3x + 9 = 24.'],
  ch:{q:'Solve 7x − 5 = 37.',a:'7x = 42, so x = 6.'}},
 {id:'im1t1-1-1b',t:'Museum trip: brackets first or divide first?',min:6,eng:'tape',
  life:'3 cousins each pay (x + 12) AED: a museum ticket x and AED 12 for the metro. Together they pay AED 105: 3(x + 12) = 105.',
  cfg:{form:'pq',p:3,q:12,r:105,unit:'AED',story:'3 equal groups of (x + 12) make AED 105'},
  ask:['What does one part of the bar stand for?','Why can we divide by 3 first?','Solve it again by distributing first. Same answer?','Which method is quicker here? When is the other method better?'],
  ch:{q:'Solve 5(x − 4) = 65 in two ways.',a:'Divide first: x − 4 = 13, x = 17. Distribute: 5x − 20 = 65, 5x = 85, x = 17.'}},
 {id:'im1t1-1-1c',t:'Clear the decimals',min:7,eng:'expr',
  life:'Prices and distances often use decimals. Multiplying every term by 10 turns 0.4x + 1.2 = 0.2x + 3 into whole numbers.',
  cfg:{steps:[{e:'0.4x + 1.2 = 0.2x + 3',note:'Decimals with one decimal place. Multiply every term by 10.'},{e:'4x + 12 = 2x + 30',note:'10 × 0.4x = 4x, 10 × 1.2 = 12, 10 × 0.2x = 2x, 10 × 3 = 30.',hl:'4x + 12'},{e:'2x + 12 = 30',note:'Subtract 2x from both sides.'},{e:'2x = 18',note:'Subtract 12 from both sides.'},{e:'x = 9',note:'Divide both sides by 2.'},{e:'Check: 0.4(9) + 1.2 = 4.8 and 0.2(9) + 3 = 4.8 ✓',note:'Substitute into the ORIGINAL equation.'}]},
  ask:['Why multiply by 10 and not by 100?','What happens if you forget to multiply the 3 by 10?','Solve it without clearing the decimals. Same answer?','What would you multiply by for 0.25x + 1.5 = 4?'],
  ch:{q:'Solve 0.6x − 1.5 = 0.3x + 2.4.',a:'Multiply by 10: 6x − 15 = 3x + 24, 3x = 39, x = 13.'}}
],roby:[
 {say:'To solve, undo the operations in reverse order, and do the same to both sides.',vis:{t:'eq',l:['4x + 6 = 30','4x = 24','x = 6']}},
 {say:'With brackets you can divide first, or distribute first.',vis:{t:'eq',l:['3(x + 12) = 105','x + 12 = 35','x = 23']}},
 {say:'Decimals: multiply every term by 10 to work with whole numbers.',vis:{t:'eq',l:['0.4x + 1.2 = 0.2x + 3','4x + 12 = 2x + 30','x = 9']}},
 {say:'Always check in the original equation.',vis:{t:'ans',s:'0.4(9) + 1.2 = 4.8 = 0.2(9) + 3 ✓'}}
]},

{code:'1-2',mod:'Topic 1 · Solving Equations and Inequalities',title:'Solving Equations With a Variable on Both Sides',acts:[
 {id:'im1t1-1-2a',t:'Algebra tiles: x on both sides',min:7,eng:'lin',
  life:'5 bags of dates and 3 kg balance 2 bags and 18 kg. Take the same number of bags from both sides first.',
  cfg:{mode:'tiles',p:5,q:3,r:2,s:18,gmax:10,say:'Guess the mass of one bag with the slider, or solve step by step.'},
  ask:['Why remove 2 bags from BOTH sides?','Why is it easier to remove the smaller x-term?','Check your answer on both sides.','Write the steps as equations.'],
  ch:{q:'Solve 7x + 4 = 3x + 28.',a:'4x + 4 = 28, 4x = 24, x = 6.'}},
 {id:'im1t1-1-2b',t:'Bike rental at Kite Beach',min:8,eng:'lin',
  life:'Shop A: AED 20 + AED 15 per hour. Shop B: AED 50 + AED 10 per hour. When do they cost the same? 20 + 15x = 50 + 10x.',
  cfg:{mode:'graph',plans:true,L:'20 + 15*x',R:'50 + 10*x',Ls:'20 + 15x',Rs:'50 + 10x',names:['Shop A','Shop B'],xmin:0,xmax:10,x0:2,yL:'AED',xL:'hours',btn:'When do they cost the same?',meet:'Same cost after this many hours.',say:'Slide the hours. Which shop is cheaper for a short ride? When are they equal?'},
  ask:['Which shop is cheaper for 2 hours? For 9 hours?','Write and solve the equation.','What does the meeting point mean in words?','You want to ride all afternoon (5 hours). Which shop?'],
  ch:{q:'Plan A: AED 45 + AED 3 per class. Plan B: AED 15 + AED 5 per class. When are they equal?',a:'45 + 3x = 15 + 5x, 30 = 2x, x = 15 classes.'}},
 {id:'im1t1-1-2c',t:'Identity or no solution?',min:6,eng:'lin',
  life:'Some equations are true for every number (an identity), and some are never true. Graph both sides to see which.',
  cfg:{mode:'graph',L:'3*(x+4)',R:'3*x+12',Ls:'3(x + 4)',Rs:'3x + 12',names:['Left','Right'],xmin:0,xmax:8,x0:2,btn:'Do they meet?',say:'Slide x. Are the two sides ever different?'},
  ask:['Simplify 3(x + 4). What do you notice?','What happens when you solve 3(x + 4) = 3x + 12?','Change the right side to 3x + 10. What case is it now?','Write your own identity.'],
  ch:{q:'Classify: 2(x − 1) = 2x + 5 and 4x − 8 = 4(x − 2).',a:'No solution (−2 = 5 is false); identity, infinitely many solutions (−8 = −8).'}}
],roby:[
 {say:'Move the smaller x-term first, so the x-term stays positive.',vis:{t:'eq',l:['5x + 3 = 2x + 18','3x + 3 = 18','3x = 15','x = 5']}},
 {say:'The solution is where the graphs of the two sides meet.',vis:{t:'tab',h:['Hours','Shop A','Shop B'],r:[['2','50','70'],['6','110','110'],['8','140','130']]}},
 {say:'Three things can happen when you solve.',vis:{t:'tab',h:['You get','Meaning'],r:[['x = 5','one solution'],['−2 = 5 (false)','no solution'],['12 = 12 (true)','identity: infinitely many']]}}
]},

{code:'1-3',mod:'Topic 1 · Solving Equations and Inequalities',title:'Literal Equations and Formulas',acts:[
 {id:'im1t1-1-3a',t:'Fence a garden: solve P = 2l + 2w for w',min:7,eng:'expr',
  life:'A gardener has 40 m of fence and wants a 12 m long garden. Rearranging the perimeter formula gives the width straight away.',
  cfg:{steps:[{e:'P = 2l + 2w',note:'Goal: get w on its own. Treat P and l like numbers.'},{e:'P − 2l = 2w',note:'Subtract 2l from both sides.',hl:'P − 2l'},{e:'(P − 2l) ÷ 2 = w',note:'Divide both sides by 2.'},{e:'w = (P − 2l) / 2',note:'Write the new formula with w first.'},{e:'w = (40 − 24) / 2 = 8 m',note:'Use it: P = 40 m and l = 12 m.'},{e:'Check: 2(12) + 2(8) = 40 ✓',note:'Substitute back into the original formula.'}]},
  ask:['Which variable are we solving for?','Why treat P and l like numbers?','Is w = P/2 − l the same formula? Show why.','Use the new formula for P = 50 m and l = 15 m.'],
  ch:{q:'Solve A = lw for l. Then find l when A = 96 m² and w = 8 m.',a:'l = A / w = 96 / 8 = 12 m.'}},
 {id:'im1t1-1-3b',t:'Dubai summer in °F',min:6,eng:'expr',
  life:'A tourist from the USA reads 45 °C on a Dubai sign. Solve F = 9/5·C + 32 for C, so you can convert either way.',
  cfg:{steps:[{e:'F = (9/5)C + 32',note:'Start: Fahrenheit from Celsius.'},{e:'F − 32 = (9/5)C',note:'Subtract 32 from both sides.'},{e:'(5/9)(F − 32) = C',note:'Multiply both sides by 5/9, the reciprocal of 9/5.',hl:'(5/9)'},{e:'C = (5/9)(F − 32)',note:'New formula: Celsius from Fahrenheit.'},{e:'45 °C → F = (9/5)(45) + 32 = 113 °F',note:'Use the original formula for the sign.'},{e:'Check: (5/9)(113 − 32) = (5/9)(81) = 45 ✓',note:'The two formulas undo each other.'}]},
  ask:['Why multiply by 5/9 and not divide by 9?','What is 0 °C in °F? What is 212 °F in °C?','Which formula would a weather app in the USA use?','Is there a temperature that is the same in both scales?'],
  ch:{q:'Convert 77 °F to °C.',a:'C = (5/9)(77 − 32) = (5/9)(45) = 25 °C.'}},
 {id:'im1t1-1-3c',t:'Spot the mistake: solve A = ½bh for h',min:6,eng:'expr',
  life:'A sail maker knows the area of a triangular dhow sail and its base, and needs its height. Two students rearrange the formula.',
  cfg:{steps:[{e:'A = ½bh',note:'Goal: h on its own.'},{e:'2A = bh',note:'Multiply both sides by 2 to clear the fraction.'},{e:'h = 2A / b',note:'Divide both sides by b.'}],rightName:'Layla',compare:{name:'Hamdan',steps:[{e:'A = ½bh'},{e:'A ÷ ½ = bh'},{e:'h = A / 2b'}]}},
  ask:['Test both formulas with A = 12 and b = 4. Which gives h = 6?','Where did Hamdan go wrong?','Why is dividing by ½ the same as multiplying by 2?','Find h for a sail with A = 18 m² and b = 6 m.'],
  ch:{q:'Solve V = lwh for h.',a:'h = V / (lw).'}}
],roby:[
 {say:'A literal equation has more than one letter. Solve for one letter and treat the others like numbers.',vis:{t:'big',s:'Solve for ONE variable'}},
 {say:'Use the same inverse operations as always.',vis:{t:'eq',l:['P = 2l + 2w','P − 2l = 2w','w = (P − 2l) / 2']}},
 {say:'A rearranged formula answers many questions quickly.',vis:{t:'tab',h:['P (m)','l (m)','w (m)'],r:[['40','12','8'],['50','15','10'],['30','9','6']]}}
]},

{code:'1-4',mod:'Topic 1 · Solving Equations and Inequalities',title:'Solving Inequalities in One Variable',acts:[
 {id:'im1t1-1-4a',t:'Solve, flip and graph',min:7,eng:'ineq',
  life:'Engineers set safe limits with inequalities. Watch what happens when we divide by a negative number.',
  cfg:{mode:'solve',a:-3,b:4,sym:'<=',c:-2,min:-6,max:6,v:'x',t0:0},
  ask:['What is the first step? Why?','Why does the sign flip in the last step?','Test x = 0 and x = 3 in the ORIGINAL inequality.','Solve 3x + 4 ≤ −2 and compare.'],
  ch:{q:'Solve and graph 5 − 2x > 11.',a:'−2x > 6, so x < −3.'}},
 {id:'im1t1-1-4b',t:'Mobile data top-up budget',min:7,eng:'motion',
  life:'A prepaid plan costs AED 25 plus AED 8 for each extra GB. To spend at most AED 90: 25 + 8g ≤ 90.',
  cfg:{scene:'meter',p:8,q:25,r:90,rel:'<=',int:true,xmax:12,ymax:130,xn:'g',yn:'bill',xL:'extra GB',yL:'bill (AED)',icon:'app',ic:'teal',money:true,rL:'budget',rName:'budget (AED)',pName:'AED per GB',unitX:'GB',sl:{p:[4,12,1],r:[50,130,5]},
   say:'Solve the inequality first, then press Show solution to check.'},
  ask:['Write the inequality from the story.','The algebra gives g ≤ 8.125. Why is the answer 8 GB?','Where does the line cross the budget line?','Change the price per GB. How does the answer change?'],
  ch:{q:'A gym charges AED 120 to join and AED 60 a month. Budget AED 600. How many months?',a:'120 + 60m ≤ 600, m ≤ 8: at most 8 months.'}},
 {id:'im1t1-1-4c',t:'Why the sign flips',min:6,eng:'ineq',
  life:'−2 < 3 is true. Multiply both sides by −3: 6 and −9. Now 6 > −9, so the order reverses.',
  cfg:{mode:'flip',a:-2,b:3,k:-3,min:-12,max:12,lab:3,say:'Choose a multiplier, then press Multiply! Watch the two points swap sides.'},
  ask:['Before multiplying, which number is on the left?','After multiplying by −3, which is on the left?','Try a positive multiplier. Does the order change?','Write the rule in your own words.'],
  ch:{q:'Solve −6x ≥ 18.',a:'Divide by −6 and flip: x ≤ −3.'}}
],roby:[
 {say:'Solve an inequality like an equation, with one extra rule.',vis:{t:'eq',l:['−3x + 4 ≤ −2','−3x ≤ −6','x ≥ 2']}},
 {say:'Multiplying or dividing by a negative number reverses the inequality sign.',vis:{t:'eq',l:['−2 < 3','× (−3)','6 > −9']}},
 {say:'Closed circle for ≤ or ≥, open circle for < or >.',vis:{t:'nl',min:-2,max:6,shade:[2,'r',true],pts:[[2,'x ≥ 2','g']]}}
]},

{code:'1-5',mod:'Topic 1 · Solving Equations and Inequalities',title:'Compound Inequalities',acts:[
 {id:'im1t1-1-5a',t:'AND: the safe pool temperature',min:7,eng:'expr',
  life:'A school pool must stay between 26 °C and 30 °C. The heater setting x gives 2x + 20 °C, so 26 ≤ 2x + 20 ≤ 30.',
  cfg:{steps:[{e:'26 ≤ 2x + 20 ≤ 30',note:'An AND inequality: both parts must be true at the same time.'},{e:'6 ≤ 2x ≤ 10',note:'Subtract 20 from ALL three parts.',hl:'6 ≤ 2x ≤ 10'},{e:'3 ≤ x ≤ 5',note:'Divide all three parts by 2.'},{e:'Graph: closed circles at 3 and 5, shade between',note:'AND: the overlap of x ≥ 3 and x ≤ 5.'},{e:'Check x = 4: 2(4) + 20 = 28 °C ✓',note:'Test a value inside, then one outside (x = 6 gives 32 °C ✗).'}]},
  ask:['Why must we do the same to all three parts?','Is x = 5 allowed? Is x = 5.5?','Write the answer as two inequalities joined by AND.','What would the graph look like if the limits were 26 < … < 30?'],
  ch:{q:'Solve −3 < 2x + 1 ≤ 9.',a:'−4 < 2x ≤ 8, so −2 < x ≤ 4.'}},
 {id:'im1t1-1-5b',t:'OR: medicine fridge alarm',min:7,eng:'expr',
  life:'A pharmacy fridge alarm rings if the temperature is too cold OR too warm. An OR inequality is true if at least one part is true.',
  cfg:{steps:[{e:'2x + 3 < 1   OR   x − 4 ≥ −1',note:'Two separate inequalities joined by OR.'},{e:'2x < −2   OR   x ≥ 3',note:'Solve each part on its own.'},{e:'x < −1   OR   x ≥ 3',note:'Divide the first part by 2.'},{e:'Graph: open circle at −1 shading left; closed circle at 3 shading right',note:'OR: put both pieces on the same number line.'},{e:'Check x = 0: 2(0) + 3 < 1? No. 0 − 4 ≥ −1? No. ✗',note:'0 is in the gap, so it is NOT a solution.'}]},
  ask:['Why does the graph have a gap?','Is x = 3 a solution? Is x = −1?','How is OR different from AND?','Can an AND inequality ever have no solution? Give an example.'],
  ch:{q:'Solve 3x − 2 ≤ −8 OR 4x + 1 > 13.',a:'x ≤ −2 OR x > 3.'}}
],roby:[
 {say:'AND means both parts are true: the graph is the overlap.',vis:{t:'eq',l:['26 ≤ 2x + 20 ≤ 30','6 ≤ 2x ≤ 10','3 ≤ x ≤ 5']}},
 {say:'OR means at least one part is true: the graph can have two pieces.',vis:{t:'eq',l:['2x + 3 < 1  OR  x − 4 ≥ −1','x < −1  OR  x ≥ 3']}},
 {say:'Always test one value inside and one outside.',vis:{t:'tab',h:['x','AND: 3 ≤ x ≤ 5','OR: x < −1 or x ≥ 3'],r:[['0','✗','✗'],['4','✓','✓'],['−2','✗','✓']]}}
]},

{code:'1-6',mod:'Topic 1 · Solving Equations and Inequalities',title:'Absolute Value Equations and Inequalities',acts:[
 {id:'im1t1-1-6a',t:'Where does |x − h| reach k?',min:7,eng:'fx',
  life:'Absolute value is distance. |x − h| = k asks: which numbers are k units away from h? There are usually two.',
  cfg:{fs:[{f:'abs(x-h)',s:'y = |x − h|'},{f:'k',s:'y = k',dash:true}],params:[{k:'h',l:'h (centre) =',min:-4,max:4,step:1,v:1},{k:'k',l:'k (distance) =',min:0,max:6,step:1,v:3}],
   xmin:-8,xmax:8,ymin:-3,ymax:9,x0:0,tstep:1,btn:'Show the solutions',pts:[['h-k','k','x = #x'],['h+k','k','x = #x']],
   out:[{l:'Left solution:  x = h − k = ',f:'h-k'},{l:'Right solution:  x = h + k = ',f:'h+k'}],
   say:'Move h and k. Where does the V-shaped graph meet the line y = k? Try k = 0.'},
  ask:['Why are there usually two solutions?','What happens when k = 0?','What if k were negative? Why would there be no solution?','Solve |x − 1| = 3 without the graph.'],
  ch:{q:'Solve |x + 2| = 5.',a:'x + 2 = 5 or x + 2 = −5, so x = 3 or x = −7.'}},
 {id:'im1t1-1-6b',t:'Solve |2x − 3| = 7',min:6,eng:'expr',
  life:'If the distance from zero is 7, the inside can be 7 or −7. Split into two equations.',
  cfg:{steps:[{e:'|2x − 3| = 7',note:'The absolute value is already on its own.'},{e:'2x − 3 = 7   OR   2x − 3 = −7',note:'The inside is 7 units from 0: it is 7 or −7.'},{e:'2x = 10   OR   2x = −4',note:'Add 3 to both sides of each equation.'},{e:'x = 5   OR   x = −2',note:'Divide by 2.'},{e:'Check: |2(5) − 3| = 7 ✓   |2(−2) − 3| = |−7| = 7 ✓',note:'Both solutions work.'}]},
  ask:['Why do we write two equations?','What is the first step for 3|x − 1| + 2 = 14?','Why does |x| = −4 have no solution?','Check both answers.'],
  ch:{q:'Solve 2|x − 4| + 1 = 11.',a:'|x − 4| = 5, so x = 9 or x = −1.'}},
 {id:'im1t1-1-6c',t:'Classroom thermostat: |t − 24| ≤ 2',min:7,eng:'expr',
  life:'A classroom air-conditioner keeps the room within 2 °C of 24 °C. That is |t − 24| ≤ 2: an AND inequality.',
  cfg:{steps:[{e:'|t − 24| ≤ 2',note:'Distance from 24 is at most 2.'},{e:'−2 ≤ t − 24 ≤ 2',note:'“Less than” absolute value becomes an AND inequality.'},{e:'22 ≤ t ≤ 26',note:'Add 24 to all three parts.'},{e:'Graph: closed circles at 22 and 26, shade between',note:'All temperatures from 22 °C to 26 °C.'},{e:'Check t = 25: |25 − 24| = 1 ≤ 2 ✓;  t = 27: |3| = 3 ✗',note:'Test inside and outside.'}]},
  ask:['Why does ≤ give an AND inequality?','What would |t − 24| > 2 mean for the room?','Write |t − 24| > 2 as an OR inequality.','Write an absolute value inequality for 18 ≤ x ≤ 30.'],
  ch:{q:'Solve |x + 1| > 4.',a:'x + 1 > 4 OR x + 1 < −4, so x > 3 OR x < −5.'}}
],roby:[
 {say:'Absolute value means distance from zero, so it is never negative.',vis:{t:'nl',min:-8,max:8,lab:2,pts:[[-7,'−7','r'],[7,'7','g']]}},
 {say:'An absolute value equation usually splits into two equations.',vis:{t:'eq',l:['|2x − 3| = 7','2x − 3 = 7  or  2x − 3 = −7','x = 5  or  x = −2']}},
 {say:'Less than means AND. Greater than means OR.',vis:{t:'tab',h:['Inequality','Becomes'],r:[['|x − 24| ≤ 2','22 ≤ x ≤ 26'],['|x + 1| > 4','x < −5 or x > 3']]}}
]}
]});

/* ---------------- lesson lists for the other topics ---------------- */
{
const T=(unit,tag,title,list)=>ARENA.unit({grade:'IM1',unit,tag,title,lessons:list.map(([code,t])=>({code,mod:tag+' · '+title,title:t,acts:[]}))});
T(2,'Topic 2','Linear Equations',[['2-1','Slope-Intercept Form'],['2-2','Point-Slope Form'],['2-3','Standard Form'],['2-4','Parallel and Perpendicular Lines']]);
T(3,'Topic 3','Linear Functions',[['3-1','Relations and Functions'],['3-2','Linear Functions'],['TN-2','Understanding Geometric Formulas as Functions'],['3-3','Transforming Linear Functions'],['3-4','Arithmetic Sequences'],['3-5','Scatter Plots and Lines of Fit'],['3-6','Analyzing Lines of Fit']]);
T(4,'Topic 4','Systems of Linear Equations and Inequalities',[['4-1','Solving Systems of Equations by Graphing'],['4-2','Solving Systems of Equations by Substitution'],['4-3','Solving Systems of Equations by Elimination'],['4-4','Linear Inequalities in Two Variables'],['4-5','Systems of Linear Inequalities'],['TN-3','Linear Systems'],['TN-4','Operations with Matrices'],['TN-5','Matrix Multiplication'],['TN-6','Solving Linear Systems Using Matrices']]);
T(5,'Topic 5','Exponents and Exponential Functions',[['5-1','Rational Exponents and Properties of Exponents'],['5-2','Exponential Functions'],['5-3','Exponential Growth and Decay'],['5-4','Geometric Sequences'],['5-5','Transformations of Exponential Functions']]);
T(6,'Topic 6','Foundations of Geometry',[['6-1','Measuring Segments and Angles'],['6-2','Basic Constructions'],['6-3','Midpoint and Distance'],['6-4','Inductive Reasoning'],['6-5','Conditional Statements'],['6-6','Deductive Reasoning'],['6-7','Writing Proofs'],['6-8','Indirect Proof'],['7-3','Perpendicular and Angle Bisectors (Math II)'],['7-4','Bisectors in Triangles (Math II)']]);
T(7,'Topic 7','Parallel and Perpendicular Lines',[['7-1','Properties of Parallel Lines'],['7-2','Proving Lines Parallel'],['7-3','Parallel Lines and Triangle Angle Sums'],['7-4','Slopes of Parallel and Perpendicular Lines'],['9-2','Isosceles and Equilateral Triangles']]);
T(8,'Topic 11 · Math II','Coordinate Geometry',[['11-1','Polygons in the Coordinate Plane'],['11-2','Proofs Using Coordinate Geometry'],['11-3','Circles in the Coordinate Plane'],['11-4','Parabolas in the Coordinate Plane'],['TN-7','Translations'],['TN-8','Reflections'],['TN-9','Rotations'],['TN-10','Dilations']]);
}
