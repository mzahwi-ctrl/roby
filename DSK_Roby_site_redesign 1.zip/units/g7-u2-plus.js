/* Grade 7 · Unit 2 — two extra UAE daily-life activities per lesson + Roby lessons. */
ARENA.extend({grade:7,unit:2,lessons:{

'7.1':{acts:[
 {id:'g7u2-7.1d',t:'5% VAT: two ways to write the total',min:7,eng:'equiv',
  life:'UAE shops add 5% VAT. A price x becomes x + 0.05x, which is the same as 1.05x.',
  cfg:{pairs:[['x + 0.05x','1.05x'],['x + 0.05x','x + 0.05']],names:['Price + VAT','Total'],xmin:0,xmax:200,step:10,x0:100,yL:'AED',say:'Slide the price x. Then compare with the wrong form x + 0.05.'},
  ask:['What does 0.05x mean at the till?','Why is x + 0.05x the same as 1.05x?','Which form is quicker on a calculator?','Why is x + 0.05 wrong?'],
  ch:{q:'A phone costs AED 2,400 before VAT. Write the total in two forms and find it.',a:'2400 + 0.05(2400) = 1.05(2400) = AED 2,520'}},
 {id:'g7u2-7.1e',t:'Class shawarma order',min:6,eng:'area',
  life:'6 students each buy a shawarma for x dirhams and a juice for AED 4: 6(x + 4) or 6x + 24.',
  cfg:{mode:'distribute',a:6,k:4,x:7,v:'x',unit:'AED',story:'Each student pays (x + 4)',say:'Change the number of students and the shawarma price.'},
  ask:['Which form shows what one student pays?','Which form shows the total for the juices?','If x = 7, what is the total?','Write the total for 9 students.'],
  ch:{q:'Rewrite 8(x + 2.5) without brackets.',a:'8x + 20'}}
],roby:[
 {say:'The same situation can be written in different forms. Price minus 20 percent is the same as 0.8 times the price.',vis:{t:'eq',l:['p − 0.2p','= 0.8p']}},
 {say:'20 percent off means you pay 80 percent.',vis:{t:'bar',total:'p (100%)',parts:[['you pay 0.8p',8,'p'],['0.2p off',2,'g']]}},
 {say:'Perimeter can be 2 l plus 2 w, or 2 times l plus w.',vis:{t:'eq',l:['2l + 2w = 2(l + w)']}},
 {say:'Each form shows something different: 4 times x plus 15 shows one person’s cost; 4 x plus 60 shows the total bus money.',vis:{t:'eq',l:['4(x + 15) = 4x + 60']}},
 {say:'VAT: price plus 5 percent is x plus 0.05 x, which is 1.05 x.',vis:{t:'eq',l:['x + 0.05x = 1.05x']}}
]},

'7.2':{acts:[
 {id:'g7u2-7.2d',t:'Iftar boxes: factor 12x + 18',min:7,eng:'area',
  life:'A charity packs 12x + 18 dates into identical iftar boxes. The most boxes uses the GCF: 6(2x + 3).',
  cfg:{mode:'factor',terms:[12,18],fmax:12,story:'12x + 18 dates into identical iftar boxes',say:'Try each factor. Which is the greatest common factor?'},
  ask:['List the factors that divide both 12 and 18.','Why is 6 better than 2 or 3?','Expand 6(2x + 3) to check.','Factor 15x + 25.'],
  ch:{q:'Factor 16x + 24 completely.',a:'8(2x + 3)'}},
 {id:'g7u2-7.2e',t:'Water for a desert camp',min:7,eng:'cards',
  life:'At a desert camp, water in litres is tracked as 3/4x + 2 − 1/4x + 1/2. Combining like terms makes it 1/2x + 5/2.',
  cfg:{mode:'combine',terms:[{c:'3/4',v:'x'},{c:'2'},{c:'-1/4',v:'x'},{c:'1/2'}],test:4,story:'Camp water (litres)',notes:['Find the like terms.','x-terms together, constants together.','3/4 − 1/4 = 1/2, and 2 + 1/2 = 5/2.']},
  ask:['How do you subtract 1/4x from 3/4x?','Write 5/2 as a mixed number.','Test x = 4 in both forms.','Simplify 2/3x + 1 + 1/3x − 4.'],
  ch:{q:'Simplify 0.6y + 3 − 0.2y − 1.5.',a:'0.4y + 1.5'}}
],roby:[
 {say:'Add like terms by adding their coefficients: one half x plus one quarter x is three quarters x.',vis:{t:'eq',l:['1/2x + 1/4x','= 2/4x + 1/4x','= 3/4x']}},
 {say:'To subtract a bracket, change the sign of every term inside it.',vis:{t:'eq',l:['(5x + 4) − (2x − 3)','= 5x + 4 − 2x + 3']}},
 {say:'Then combine: 3x plus 7.',vis:{t:'eq',l:['= 3x + 7']}},
 {say:'To factor, find the greatest common factor. For 6x plus 9, the GCF of 6 and 9 is 3.',vis:{t:'area',a:'3',parts:[['2x',2.4],['3',1.2]],prods:['6x','9']}},
 {say:'So 6x plus 9 equals 3 times 2x plus 3. Check by expanding.',vis:{t:'eq',l:['6x + 9 = 3(2x + 3)','check: 3·2x + 3·3 = 6x + 9 ✓']}}
]},

'7.3':{acts:[
 {id:'g7u2-7.3d',t:'Camel feed scale',min:7,eng:'balance',
  life:'A camel farm weighs feed: 2 equal sacks and a 7 kg bucket balance 15 kg, so 2x + 7 = 15.',
  cfg:{p:2,q:7,r:15,bag:'sack',unit:'kg',gmax:8,say:'Guess the mass of one sack, or solve step by step.'},
  ask:['Write the equation the scale shows.','Which step comes first? Why?','Check your answer on the scale.','Write an equation for 3 sacks and a 5 kg bucket balancing 20 kg.'],
  ch:{q:'Solve 3x + 5 = 20.',a:'3x = 15, so x = 5.'}},
 {id:'g7u2-7.3e',t:'Cinema tickets and snacks',min:6,eng:'tape',
  life:'5 cinema tickets plus AED 20 of snacks cost AED 95 in total: 5x + 20 = 95.',
  cfg:{form:'pxq',p:5,q:20,r:95,unit:'AED',story:'5 tickets + AED 20 snacks = AED 95'},
  ask:['What does each blue part stand for?','Why do we take away 20 first?','Check: 5(15) + 20 = ?','Write a story for 4x + 12 = 60.'],
  ch:{q:'Solve 4x + 12 = 60.',a:'4x = 48, so x = 12.'}}
],roby:[
 {say:'A two-step equation has a rate and a starting amount, like 2.5 d plus 12 equals 42.',vis:{t:'eq',l:['2.5d + 12 = 42']}},
 {say:'In the story: 12 dirhams to start, plus 2.50 dirhams per kilometre, makes 42 dirhams.',vis:{t:'bar',total:'42',parts:[['12 start',12,'g'],['2.5d per km',30,'p']]}},
 {say:'Take away the start amount from both sides: 2.5 d equals 30.',vis:{t:'eq',l:['2.5d + 12 − 12 = 42 − 12','2.5d = 30']}},
 {say:'Divide by the rate: d equals 12 kilometres.',vis:{t:'eq',l:['d = 30 ÷ 2.5','d = 12']}},
 {say:'Another form: 4 times x plus 5 equals 60. Divide by 4, then subtract 5: x equals 10.',vis:{t:'eq',l:['4(x + 5) = 60','x + 5 = 15','x = 10']}}
]},

'7.4':{acts:[
 {id:'g7u2-7.4d',t:'Theme park rides',min:7,eng:'motion',
  life:'A theme park ticket costs AED 15 plus AED 2.50 per ride. Hamad spent AED 45, so 2.5r + 15 = 45.',
  cfg:{scene:'meter',p:2.5,q:15,r:45,rel:'=',int:true,xmax:20,ymax:70,xn:'r',yn:'cost',xL:'rides',yL:'cost (AED)',icon:'ticket',ic:'pink',money:true,rL:'spent',rName:'spent (AED)',unitX:'rides',sl:{r:[20,65,2.5]},say:'Press Play: each ride adds AED 2.50. When does the cost reach AED 45?'},
  ask:['Write the equation for AED 45.','Solve it with inverse operations.','Where is the answer on the graph?','How many rides for AED 40? Is that possible exactly?'],
  ch:{q:'A bowling alley charges AED 20 entry plus AED 12 per game. Mona spent AED 68. How many games?',a:'12g + 20 = 68, so g = 4.'}},
 {id:'g7u2-7.4e',t:'Karak and pastry for friends',min:6,eng:'tape',
  life:'3 friends each buy karak for x dirhams and a pastry for AED 2.50. The bill is AED 34.50: 3(x + 2.5) = 34.5.',
  cfg:{form:'pq',p:3,q:2.5,r:34.5,unit:'AED',story:'3 friends each pay (x + 2.50) = AED 34.50'},
  ask:['What does x + 2.5 stand for?','Why divide by 3 first?','Check your answer in the story.','Write the same problem as px + q = r.'],
  ch:{q:'Solve 4(x + 1.5) = 26.',a:'x + 1.5 = 6.5, so x = 5.'}}
],roby:[
 {say:'To solve an equation, undo the operations in reverse order.',vis:{t:'eq',l:['4x + 6 = 30']}},
 {say:'Undo plus 6: subtract 6 from both sides.',vis:{t:'eq',l:['4x + 6 − 6 = 30 − 6','4x = 24']}},
 {say:'Undo times 4: divide both sides by 4.',vis:{t:'eq',l:['4x ÷ 4 = 24 ÷ 4','x = 6']}},
 {say:'Always check in the story: 4 boxes of 6 kilograms plus 6 kilograms is 30 kilograms.',vis:{t:'eq',l:['4(6) + 6 = 24 + 6 = 30 ✓']}},
 {say:'Decimals work the same way: 3x plus 4.5 equals 22.5, so 3x equals 18, and x equals 6.',vis:{t:'eq',l:['3x + 4.5 = 22.5','3x = 18','x = 6']}}
]},

'7.5':{acts:[
 {id:'g7u2-7.5d',t:'Road junction: vertical angles',min:6,eng:'angles',
  life:'Where two straight roads cross, the opposite angles at the junction are equal: vertical angles.',
  cfg:{mode:'vert',th0:45,target:65,eq:{a:3,b:5,known:65},prob:'∠1 = 65°,  ∠3 = (3x + 5)°.  Find x.',
   steps:[{e:'∠3 = ∠1  (vertical angles)',n:'Vertical angles are always equal.'},{e:'3x + 5 = 65',n:'Write the equation.'},{e:'3x = 60',n:'Subtract 5 from both sides.'},{e:'x = 20',n:'Divide both sides by 3. Check: 3(20) + 5 = 65 ✓'}],
   say:'Drag the orange handle to turn one road.'},
  ask:['Which angles stay equal as the road turns?','What do ∠1 and ∠2 add up to?','Write and solve the equation.','If ∠2 = (2x + 15)° and ∠1 = 65°, write the equation.'],
  ch:{q:'Two vertical angles are (4x − 10)° and 70°. Find x.',a:'4x − 10 = 70, so x = 20.'}},
 {id:'g7u2-7.5e',t:'Dhow sail and deck',min:6,eng:'angles',
  life:'A dhow’s mast meets the flat deck: the two angles on either side of the mast make a straight line, 180°.',
  cfg:{mode:'supp',th0:70,target:110,eq:{a:2,b:10,known:110},prob:'∠1 = 110°,  ∠2 = (2x + 10)°.  Find x.',
   steps:[{e:'∠1 + ∠2 = 180°',n:'Angles on a straight line are supplementary.'},{e:'110 + 2x + 10 = 180',n:'Substitute both angles.'},{e:'2x + 120 = 180',n:'Combine the constants.'},{e:'2x = 60',n:'Subtract 120 from both sides.'},{e:'x = 30',n:'Divide by 2. Check: 2(30) + 10 = 70, and 110 + 70 = 180 ✓'}],
   say:'Drag the mast. The two angles always add to 180°.'},
  ask:['What stays the same as you drag?','If ∠1 is 120°, what is ∠2?','Solve the problem step by step.','Can both angles be obtuse? Why not?'],
  ch:{q:'Supplementary angles are (5x)° and (x + 30)°. Find x.',a:'6x + 30 = 180, so x = 25.'}}
],roby:[
 {say:'Vertical angles are opposite each other where two lines cross. They are always equal.',vis:{t:'ang',m:'vert',deg:70}},
 {say:'Supplementary angles make a straight line. They add to 180 degrees.',vis:{t:'ang',m:'supp',deg:75}},
 {say:'Complementary angles make a right angle. They add to 90 degrees.',vis:{t:'ang',m:'comp',deg:40}},
 {say:'Write an equation: 75 plus 3x plus 15 equals 180. Then solve it.',vis:{t:'eq',l:['75 + (3x + 15) = 180','3x + 90 = 180','3x = 90','x = 30']}},
 {say:'Check: 3 times 30 plus 15 is 105, and 75 plus 105 is 180.',vis:{t:'eq',l:['3(30) + 15 = 105','75 + 105 = 180 ✓']}}
]},

'8.1':{acts:[
 {id:'g7u2-8.1d',t:'Highway speed limit',min:6,eng:'ineq',
  life:'UAE highways show speed limits such as 120 km/h. Allowed speeds s satisfy s ≤ 120.',
  cfg:{mode:'test',sym:'<=',bound:120,min:60,max:160,lab:10,v:'s',unit:'km/h',t0:100,say:'Drag the car’s speed. Which speeds are allowed?'},
  ask:['Is exactly 120 km/h allowed? How does the circle show it?','Name a speed that breaks the limit.','Why is the shading to the left?','Write the inequality for "at least 60 km/h".'],
  ch:{q:'Write and graph: a school zone allows speeds less than 40 km/h.',a:'s < 40: open circle at 40, shaded to the left.'}},
 {id:'g7u2-8.1e',t:'Water for a desert trip',min:6,eng:'ineq',
  life:'A cool box holds at most 18 L. Each water bottle is 1.5 L, so the number of bottles b must satisfy 1.5b ≤ 18.',
  cfg:{mode:'discrete',p:1.5,r:18,sym:'<=',v:'b',min:0,max:15,icon:'cup',ic:'teal',t0:8,story:'Each bottle 1.5 L. The cool box holds at most 18 L.',say:'Change b, then show all the solutions.'},
  ask:['Is b = 12 allowed? b = 13?','Solve 1.5b ≤ 18.','Why are only whole numbers shown?','What if the bottles were 2 L each?'],
  ch:{q:'Solve 2.5n ≤ 20 for whole numbers n.',a:'n ≤ 8, so 0 to 8 bottles.'}}
],roby:[
 {say:'An inequality shows a range of answers, like h is at least 120.',vis:{t:'nl',min:100,max:150,lab:10,shade:[120,'r',true]}},
 {say:'A closed circle means the number is included, for less than or equal and greater than or equal. An open circle means it is not.',vis:{t:'eq',l:['h ≥ 120  →  closed ●','h > 120  →  open ○']}},
 {say:'Solve one-step inequalities like equations: x plus 5 is less than 12, so x is less than 7.',vis:{t:'eq',l:['x + 5 < 12','x < 7']}},
 {say:'But when you multiply or divide by a negative number, flip the sign!',vis:{t:'eq',l:['−2x < 8','x > −4']}},
 {say:'Why? 2 is less than 5, but times negative 2 they become −4 and −10, and −4 is greater.',vis:[{t:'nl',min:-12,max:6,lab:2,pts:[[-10,'−10','r'],[-4,'−4','g']]},{t:'eq',l:['2 < 5','−4 > −10']}]}
]},

'8.2':{acts:[
 {id:'g7u2-8.2d',t:'Saving for Global Village',min:7,eng:'motion',
  life:'Saeed has AED 50 and saves AED 25 a week. He wants at least AED 200 for Global Village: 25w + 50 ≥ 200.',
  cfg:{scene:'meter',p:25,q:50,r:200,rel:'>=',int:true,xmax:12,ymax:360,xn:'w',yn:'savings',xL:'weeks',yL:'savings (AED)',icon:'coin',money:true,rL:'target',rName:'target (AED)',unitX:'weeks',sl:{p:[10,50,5],r:[100,300,10]},say:'Press Play, then Show solution: when does he reach the target?'},
  ask:['Which words tell you the symbol is ≥?','Write the inequality.','How many weeks does he need?','Change the weekly saving to AED 30. Predict first.'],
  ch:{q:'Hessa has AED 80 and saves AED 15 a week. She needs at least AED 200. Write and solve the inequality.',a:'15w + 80 ≥ 200, so w ≥ 8 weeks.'}},
 {id:'g7u2-8.2e',t:'Mall parking charges',min:6,eng:'ineq',
  life:'A mall car park charges AED 4 to enter plus AED 3 per hour. To pay at most AED 25: 4 + 3h ≤ 25.',
  cfg:{mode:'discrete',p:3,q:4,r:25,sym:'<=',v:'h',min:0,max:12,icon:'ticket',ic:'orange',t0:5,clueY:280,phrases:[['at most','<='],['at least','>='],['more than','>'],['fewer than','<']],story:'Parking: AED 4 + AED 3 per hour. Pay at most AED 25.',say:'Test different numbers of hours.'},
  ask:['Which words give the symbol?','Write the inequality.','How many whole hours can you park?','What changes for "more than AED 25"?'],
  ch:{q:'Translate and solve: "5 plus 2 times a number is at least 17."',a:'5 + 2n ≥ 17, so n ≥ 6.'}}
],roby:[
 {say:'Word clues: at most means less than or equal. At least means greater than or equal. More than means greater than. Fewer than means less than.',vis:{t:'tab',h:['words','symbol'],r:[['at most','≤'],['at least','≥'],['more than','>'],['fewer than','<']]}},
 {say:'Taxi budget of 50 dirhams, 12 dirhams start plus 2.50 per kilometre.',vis:{t:'eq',l:['12 + 2.5d ≤ 50']}},
 {say:'Phone storage: 64 gigabytes, 25 already used, 4.5 per game.',vis:{t:'eq',l:['25 + 4.5a ≤ 64']}},
 {say:'Bake sale: the profit, 3.5c minus 40, must be at least 100.',vis:{t:'eq',l:['3.5c − 40 ≥ 100']}},
 {say:'Check the symbol by testing a number: d equals 10 gives 37, which is within the budget.',vis:{t:'eq',l:['d = 10:  12 + 2.5(10) = 37','37 ≤ 50 ✓']}}
]},

'8.3':{acts:[
 {id:'g7u2-8.3d',t:'Fitness challenge points',min:6,eng:'ineq',
  life:'A school fitness challenge gives 4 points per lap and takes away 6 points for warm-up help. To earn at least 10 points: 4x − 6 ≥ 10.',
  cfg:{mode:'solve',a:4,b:-6,sym:'>=',c:10,min:-6,max:10,v:'x',t0:2,story:'4 points per lap, minus 6: at least 10 points'},
  ask:['What is the first step?','Does the sign flip here? Why or why not?','Test x = 4 and x = 3.','How many laps must a student run?'],
  ch:{q:'Solve 5x + 8 < 43.',a:'5x < 35, so x < 7.'}},
 {id:'g7u2-8.3e',t:'Electricity bill limit',min:7,eng:'motion',
  life:'An electricity bill might be AED 30 plus AED 0.30 per kWh (sample rates). To keep it at most AED 90: 30 + 0.3k ≤ 90.',
  cfg:{scene:'meter',p:0.3,q:30,r:90,rel:'<=',int:true,xmax:300,ymax:130,xn:'k',yn:'bill',xL:'kWh used',yL:'bill (AED)',icon:'app',ic:'gold',money:true,rL:'limit',rName:'limit (AED)',pName:'AED per kWh',unitX:'kWh',sl:{r:[50,120,5]},say:'Press Show solution to see which amounts of electricity keep the bill within the limit.'},
  ask:['Write the inequality.','Solve it: how many kWh at most?','Where does the line cross the limit on the graph?','How could a family use fewer kWh?'],
  ch:{q:'A water bill is AED 20 plus AED 0.5 per unit. Keep it at most AED 60. How many units?',a:'20 + 0.5u ≤ 60, so u ≤ 80 units.'}}
],roby:[
 {say:'Solve two-step inequalities like equations: subtract, then divide.',vis:{t:'eq',l:['12 + 2.5d ≤ 50','2.5d ≤ 38','d ≤ 15.2']}},
 {say:'Then graph the answer on a number line.',vis:{t:'nl',min:0,max:20,lab:5,shade:[15.2,'l',true]}},
 {say:'Dividing by a negative number? Flip the sign: negative 3x plus 7 is greater than 1, so x is less than 2.',vis:{t:'eq',l:['−3x + 7 > 1','−3x > −6','x < 2']}},
 {say:'In real life, answers are often whole numbers. p is at most 11.73, so at most 11 people.',vis:{t:'eq',l:['p ≤ 11.73','→ at most 11 people']}},
 {say:'Test a value in the original inequality to check: x equals 0 gives 7, which is greater than 1.',vis:{t:'eq',l:['x = 0:  −3(0) + 7 = 7','7 > 1 ✓']}}
]}
}});
