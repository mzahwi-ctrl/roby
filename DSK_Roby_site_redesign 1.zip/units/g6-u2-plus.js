/* Grade 6 · Unit 2 — two extra UAE daily-life activities per lesson + Roby lessons.
   Roby visuals: eq (lines), big, nl (number line), bar, tab (table), grid, area, ang. */
ARENA.extend({grade:6,unit:2,lessons:{

'1.1':{acts:[
 {id:'g6u2-1.1d',t:'Gold Souq: price ups and downs',min:7,eng:'line',
  life:'Gold prices in the Dubai Gold Souq change every day. A rise is a positive integer; a fall is a negative integer.',
  cfg:{min:-8,max:8,unit:' AED',points:[{v:0,l:'Change',c:'gold'}],story:[{v:4,say:'Monday: gold rises AED 4 per gram: <b>+4</b>'},{v:-3,say:'Tuesday: it falls AED 3: <b>−3</b>'},{v:-6,say:'Wednesday: it falls AED 6: <b>−6</b>'},{v:2,say:'Thursday: it rises AED 2: <b>+2</b>'}],say:'Press <b>Play the story</b> to see each day’s change as an integer.'},
  ask:['Which days had a negative change? What does negative mean here?','Which change was the biggest fall?','What would a change of 0 mean?','Describe a change of +5 in words.'],
  ch:{q:'On Friday the price falls AED 7 per gram. Write it as an integer and give its opposite.',a:'−7; its opposite is +7 (a rise of AED 7).'}},
 {id:'g6u2-1.1e',t:'Words to integers',min:8,eng:'line',
  life:'Words like "below", "lost", "owe" and "down" mean negative. "Above", "gained", "saved" and "up" mean positive.',
  cfg:{min:-6,max:6,cards:[{v:-4,l:'lost 4 points'},{v:6,l:'saved AED 6'},{v:-2,l:'2 floors down'},{v:3,l:'3 °C warmer'},{v:0,l:'sea level'},{v:-5,l:'5 m below sea'}],say:'Drag each phrase to the integer it means, then press Check.'},
  ask:['Which words told you the number is negative?','Where does "sea level" go? Why?','Make up a phrase for +4.','Which two cards are closest together?'],
  ch:{q:'Write integers for: (a) 12 m above sea level (b) a loss of 8 points (c) 3 floors below ground.',a:'(a) +12 (b) −8 (c) −3'}}
],roby:[
 {say:'Integers are the whole numbers and their opposites: … −3, −2, −1, 0, 1, 2, 3 …',vis:{t:'nl',min:-5,max:5,pts:[[-3,'−3','r'],[0,'0','p'],[3,'3','g']]}},
 {say:'Positive numbers are to the right of zero, or above it: floors up, metres above sea level, money saved.',vis:{t:'nl',min:-5,max:5,pts:[[4,'+4 floors up','g']]}},
 {say:'Negative numbers are to the left of zero, or below it: basements, metres below sea level, money owed.',vis:{t:'nl',min:-5,max:5,pts:[[-4,'4 floors down = −4','r']]}},
 {say:'Zero is the starting point: the ground floor, sea level, or 0 °C.',vis:{t:'big',s:'0 = the starting point'}},
 {say:'Opposites are the same distance from zero on different sides. The opposite of 4 is −4.',vis:{t:'nl',min:-5,max:5,pts:[[-4,'−4','r'],[4,'4','g']],jumps:[[4,-4]]}}
]},

'1.2':{acts:[
 {id:'g6u2-1.2d',t:'DSK class league: goal difference',min:8,eng:'line',
  life:'Football tables, from the UAE Pro League to a school league, rank teams by goal difference, which can be negative.',
  cfg:{min:-10,max:15,lab:5,cards:[{v:12,l:'7D +12'},{v:7,l:'7E +7'},{v:-4,l:'7A −4'},{v:-9,l:'7B −9'},{v:0,l:'7F 0'},{v:-2,l:'7C −2'}],say:'Drag each class onto the number line by goal difference, then press Check.'},
  ask:['Which class is top of the league? Which is bottom?','Is −2 better or worse than −4? Why?','Write the table from greatest to least.','What goal difference would put a class between 7A and 7C?'],
  ch:{q:'Order these goal differences from least to greatest: 3, −7, 0, −1, 5',a:'−7, −1, 0, 3, 5'}},
 {id:'g6u2-1.2e',t:'Winter morning: Hatta or Jebel Jais?',min:6,eng:'line',
  life:'On a cold winter morning, Hatta might be 6 °C while the top of Jebel Jais is −2 °C.',
  cfg:{min:-10,max:15,lab:5,mode:'compare',unit:' °C',points:[{v:6,l:'Hatta',c:'gold'},{v:-2,l:'Jebel Jais',c:'ice'}],say:'Drag both temperatures and watch the symbol.'},
  ask:['Which place is colder? Write an inequality.','Move Jebel Jais to −8 °C. Is it colder or warmer than before?','Make both temperatures negative. Which is greater?','How many degrees warmer is Hatta?'],
  ch:{q:'Use < or >: −9 °C ___ −4 °C. Which is colder?',a:'−9 < −4, so −9 °C is colder.'}}
],roby:[
 {say:'On a number line, numbers get greater as you move to the right.',vis:{t:'nl',min:-6,max:6,pts:[[-5,'−5','r'],[-2,'−2','o'],[1,'1','p'],[3,'3','g']]}},
 {say:'−2 is to the right of −5, so −2 is greater: −2 > −5.',vis:[{t:'nl',min:-6,max:6,pts:[[-5,'−5','r'],[-2,'−2','g']]},{t:'eq',l:['−2 > −5']}]},
 {say:'Careful! 5 is bigger than 2, but −5 is farther below zero, so −5 is less than −2.',vis:{t:'eq',l:['5 > 2','but  −5 < −2']}},
 {say:'To order integers, place them on the line and read from left to right.',vis:[{t:'nl',min:-6,max:6,pts:[[3,'3','g'],[-1,'−1','o'],[-4,'−4','r'],[0,'0','p']]},{t:'eq',l:['−4, −1, 0, 3']}]},
 {say:'Your turn: order 2, −6, −3 and 5. Answer: −6, −3, 2, 5.',vis:{t:'eq',l:['2, −6, −3, 5','→  −6, −3, 2, 5']}}
]},

'1.3':{acts:[
 {id:'g6u2-1.3d',t:'Lift distance from the ground floor',min:6,eng:'line',
  life:'Whether a lift is 3 floors up or 3 floors down, it is 3 floors away from the ground floor: |3| = |−3| = 3.',
  cfg:{orient:'v',min:-4,max:6,skin:'building',floors:true,mode:'abs',ax:300,points:[{v:-3,l:'Lift',c:'red'}],say:'Drag the lift. The purple bar shows how many floors it is from the ground floor.'},
  ask:['How far is B3 from the ground floor?','Find two floors that are both 2 floors from the ground.','Why is absolute value never negative?','Is B4 or Floor 3 farther from the ground?'],
  ch:{q:'A lift goes from B2 to Floor 4. How many floors does it travel?',a:'6 floors (|−2| + |4| = 2 + 4).'}},
 {id:'g6u2-1.3e',t:'Weather app: the bigger change',min:6,eng:'line',
  life:'Weather apps show temperature changes like −6 °C or +4 °C. The bigger change has the bigger absolute value.',
  cfg:{min:-10,max:10,lab:2,mode:'abs',unit:' °C',points:[{v:-6,l:'Monday',c:'ice'},{v:4,l:'Tuesday',c:'red'}],say:'Drag the two changes. Compare the sizes of the changes, not just the signs.'},
  ask:['Which day had the bigger change?','Which change is greater as a number: −6 or 4?','Why can a bigger change be a smaller number?','Make two changes with the same absolute value.'],
  ch:{q:'Which is the bigger change: −9 °C or +7 °C? Use absolute value.',a:'−9 °C, because |−9| = 9 > |7| = 7.'}}
],roby:[
 {say:'Absolute value is the distance from zero. A distance is never negative.',vis:{t:'nl',min:-5,max:5,pts:[[-3,'−3','r']],dist:true}},
 {say:'−3 and 3 are both 3 steps from zero, so |−3| = 3 and |3| = 3.',vis:[{t:'nl',min:-5,max:5,pts:[[-3,'−3','r'],[3,'3','g']],dist:true},{t:'eq',l:['|−3| = 3','|3| = 3']}]},
 {say:'A diver at −20 m is 20 m from sea level.',vis:{t:'eq',l:['|−20| = 20 m']}},
 {say:'A balance of −50 dirhams is a debt. The size of the debt is |−50| = 50 dirhams.',vis:{t:'eq',l:['balance = −50','debt = |−50| = 50']}},
 {say:'Compare carefully: −8 is less than −2, but its absolute value is greater.',vis:{t:'eq',l:['−8 < −2','|−8| = 8 > |−2| = 2']}}
]},

'2.1':{acts:[
 {id:'g6u2-2.1d',t:'Dubai Creek tide gauge',min:6,eng:'line',
  life:'Tide gauges compare the water level with the average level (0 m). High tide might be +1.25 m and low tide −0.75 m.',
  cfg:{orient:'v',min:-2,max:2,tick:0.25,lab:0.5,skin:'sea',unit:' m',ax:280,gap:230,points:[{v:-0.75,l:'Low tide',icon:'boat',c:'orange'},{v:1.25,l:'High tide',icon:'boat',c:'blue'}],say:'Drag the boats. The water level is measured from the average level, 0 m.'},
  ask:['Read both water levels. Which is negative?','Between which two integers is −0.75?','Write −0.75 as a fraction.','How far apart are high and low tide?'],
  ch:{q:'High tide is 1 1/2 m and low tide is −1/2 m. Write both as decimals and find the difference.',a:'1.5 m and −0.5 m; the difference is 2 m.'}},
 {id:'g6u2-2.1e',t:'Dirhams and fils',min:6,eng:'line',
  life:'A dirham is split into 100 fils, so AED 2.50 and −AED 1.75 are rational numbers between whole dirhams.',
  cfg:{min:-4,max:4,sub:4,skin:'money',unit:' AED',points:[{v:2.5,l:'Nol card',c:'green'},{v:-1.75,l:'Owe',c:'red'}],say:'Drag the amounts. Each unit is split into quarters (25 fils).'},
  ask:['What does −1.75 mean in this story?','Write 2.50 as a fraction.','What is the opposite of −1.75?','Place AED 0.25. How many fils is that?'],
  ch:{q:'Plot AED −3.25 and AED 0.75. Which is farther from 0?',a:'−3.25 is farther from 0 (3.25 > 0.75).'}}
],roby:[
 {say:'Rational numbers can be written as a fraction: one half, negative three quarters, 2.5, even −6.',vis:{t:'eq',l:['1/2    −3/4','2.5 = 5/2    −6 = −6/1']}},
 {say:'They live between the integers on the number line.',vis:{t:'nl',min:-2,max:2,sub:4,pts:[[-1.25,'−1 1/4','r'],[0.5,'1/2','g']]}},
 {say:'To plot −1 3/4, split each unit into quarters and count 3 quarters to the left of −1.',vis:{t:'nl',min:-2,max:0,sub:4,pts:[[-1.75,'−1 3/4','r']],jumps:[[-1,-1.75]]}},
 {say:'Fractions and decimals can name the same point: −0.5 is the same as −1/2.',vis:{t:'tab',h:['fraction','decimal'],r:[['−1/2','−0.5'],['3/4','0.75'],['−1 3/4','−1.75']]}},
 {say:'Opposites work the same way: the opposite of 2.5 is −2.5.',vis:{t:'nl',min:-3,max:3,sub:2,pts:[[-2.5,'−2.5','r'],[2.5,'2.5','g']],jumps:[[2.5,-2.5]]}}
]},

'2.2':{acts:[
 {id:'g6u2-2.2d',t:'Sports day: ahead of or behind the record',min:8,eng:'line',
  life:'On sports day, race times are compared with the school record: −1.5 s means 1.5 seconds faster than the record.',
  cfg:{min:-3,max:3,sub:4,frac:true,tol:0.13,unit:' s',cards:[{v:-1.5,l:'Aisha −1.5 s'},{v:0.75,l:'Fatima +3/4 s'},{v:-0.25,l:'Maryam −1/4 s'},{v:2,l:'Noura +2 s'},{v:-2.25,l:'Hessa −2 1/4 s'}],say:'Drag each runner onto the line, then press Check. Negative means faster than the record.'},
  ask:['Who beat the record by the most?','Who was slowest? How do you know?','Is −1/4 greater or less than −1.5?','Order the runners from fastest to slowest.'],
  ch:{q:'Order from least to greatest: −1.2, 0.5, −1 1/4, −3/4',a:'−1 1/4, −1.2, −3/4, 0.5'}},
 {id:'g6u2-2.2e',t:'Which balance is lower?',min:6,eng:'line',
  life:'Two accounts show −AED 12.50 and −AED 12.75. The one farther left owes more, so it is the lower balance.',
  cfg:{min:-15,max:0,tick:0.25,lab:1,skin:'money',mode:'compare',unit:' AED',points:[{v:-12.5,l:'Ali',c:'red'},{v:-12.75,l:'Omar',c:'purple'}],say:'Drag the balances and read the inequality.'},
  ask:['Which balance is lower? Who owes more?','Write the comparison using <.','Move Omar to −12.25. Now who owes more?','Why does −12.75 < −12.5?'],
  ch:{q:'Compare −4.6 and −4 3/5.',a:'They are equal: −4 3/5 = −4.6.'}}
],roby:[
 {say:'To compare rational numbers, put them on the same number line.',vis:{t:'nl',min:-2,max:2,sub:4,pts:[[-1.5,'−1 1/2','r'],[-0.25,'−1/4','o'],[0.75,'3/4','g']]}},
 {say:'The number to the right is greater: 0.75 is greater than −0.25.',vis:{t:'eq',l:['0.75 > −0.25']}},
 {say:'For two negatives, the one closer to zero is greater: −1/4 is greater than −1 1/2.',vis:{t:'eq',l:['−1/4 > −1 1/2']}},
 {say:'Tip: change them all to decimals first.',vis:{t:'tab',h:['number','decimal'],r:[['−3/4','−0.75'],['2/5','0.4'],['−1 1/2','−1.5']]}},
 {say:'Now order them: −1.5, then −0.75, then 0.4.',vis:{t:'eq',l:['−1.5 < −0.75 < 0.4']}}
]},

'8.1':{acts:[
 {id:'g6u2-8.1d',t:'Laban bacteria double',min:6,eng:'power',
  life:'The good bacteria in laban and yoghurt can double about every hour while it ferments: 1, 2, 4, 8, 16 …',
  cfg:{mode:'tree',base:2,n:4,max:6,name:'bacteria',say:'Each round, every bacterium splits into 2. Move the slider.'},
  ask:['How many bacteria after 5 doublings? Write it as a power.','Why is the base 2?','After how many doublings are there more than 50?','How is 2⁶ different from 2 × 6?'],
  ch:{q:'Start with 1 bacterium that doubles 6 times. How many are there? Write it as a power.',a:'2⁶ = 64'}},
 {id:'g6u2-8.1e',t:'Square farm plots in Al Ain',min:6,eng:'power',
  life:'A square farm plot 7 m by 7 m has an area of 7² = 49 m². A cube-shaped water tank 2 m on each side holds 2³ = 8 m³.',
  cfg:{mode:'sqcube',b:7,max:8,say:'Change the side length. Switch between square (area) and cube (volume).'},
  ask:['What is the area of an 8 m by 8 m plot? Write it as a power.','What does the small 2 in 7² mean?','Switch to cube: how many 1 m³ blocks fit in a 3 m cube?','Which grows faster as b gets bigger, b² or b³?'],
  ch:{q:'A cube tank has sides of 5 m. What is its volume? Write it as a power and a number.',a:'5³ = 125 m³'}}
],roby:[
 {say:'An exponent tells you how many times to multiply the base by itself.',vis:{t:'big',s:'2⁴ = 2 × 2 × 2 × 2'}},
 {say:'Two to the fourth power equals 16. The base is 2 and the exponent is 4.',vis:{t:'eq',l:['2⁴ = 2 × 2 × 2 × 2','= 16']}},
 {say:'Squared means to the power of 2. Five squared is 5 times 5, which is 25, like a 5 by 5 square.',vis:[{t:'grid',n:5},{t:'eq',l:['5² = 5 × 5 = 25']}]},
 {say:'Cubed means to the power of 3. Three cubed is 3 times 3 times 3, which is 27.',vis:{t:'eq',l:['3³ = 3 × 3 × 3','= 27']}},
 {say:'Careful! Two cubed is not 2 times 3. Two cubed is 8, but 2 times 3 is 6.',vis:{t:'eq',l:['2³ = 2 × 2 × 2 = 8','2 × 3 = 6']}}
]},

'8.2':{acts:[
 {id:'g6u2-8.2d',t:'Karak and chapati order',min:6,eng:'expr',
  life:'At a cafeteria, 4 cups of karak at AED 1.50 and 3 chapatis at AED 2 make one numerical expression: 4 × 1.5 + 3 × 2.',
  cfg:{items:[{l:'karak',p:1.5,n:4,icon:'cup',c:'orange'},{l:'chapati',p:2,n:3,icon:'cake',c:'#c98b4a'}],
   steps:[{e:'4 × 1.5 + 3 × 2',hl:'4 × 1.5',note:'Multiply first: 4 cups × AED 1.50.'},{e:'6 + 3 × 2',hl:'3 × 2',note:'Then 3 chapatis × AED 2.'},{e:'6 + 6',hl:'6 + 6',note:'Now add.'},{e:'12',note:'The order costs <b>AED 12</b>.'}]},
  ask:['Write the order as one expression.','Why do we multiply before adding?','Add 2 more karak. What is the new expression and total?','Write the order with brackets for a family where each of 4 people has 1 karak and 1 chapati.'],
  ch:{q:'Evaluate 5 × 1.5 + 2 × 4.',a:'7.5 + 8 = 15.5'}},
 {id:'g6u2-8.2e',t:'Sharing a taxi fare',min:7,eng:'expr',
  life:'3 friends share a AED 45 taxi fare and each adds a AED 5 tip. Each pays 45 ÷ 3 + 5 dirhams.',
  cfg:{rightName:'Mariam: correct order',steps:[{e:'45 ÷ 3 + 5',hl:'45 ÷ 3',note:'Divide first: share the fare.'},{e:'15 + 5',hl:'15 + 5',note:'Then add the tip.'},{e:'20',note:'Each friend pays AED 20. Saeed got AED 5.625. Who is right?'}],
   compare:{name:'Saeed: adds first',steps:[{e:'45 ÷ 3 + 5',hl:'3 + 5'},{e:'45 ÷ 8',hl:'45 ÷ 8'},{e:'5.625'}]}},
  ask:['Where did Saeed go wrong?','Does Saeed’s answer make sense in the story? Why not?','Which expression would match Saeed’s working?','Check Mariam’s answer: 3 × 20 = ?'],
  ch:{q:'Evaluate 60 ÷ 4 + 3 and 60 ÷ (4 + 3) to 1 decimal place.',a:'18 and about 8.6'}}
],roby:[
 {say:'A numerical expression uses numbers and operations, like 3 times 4 plus 2 times 7.',vis:{t:'big',s:'3 × 4 + 2 × 7'}},
 {say:'Follow the order: brackets, then exponents, then multiply or divide, then add or subtract, working left to right.',vis:{t:'tab',h:['order','do this'],r:[['1','( ) brackets'],['2','exponents'],['3','× and ÷, left to right'],['4','+ and −, left to right']]}},
 {say:'Example: 20 minus 2 times 3 squared. Exponent first: 3 squared is 9.',vis:{t:'eq',l:['20 − 2 × 3²','= 20 − 2 × 9']}},
 {say:'Then multiply: 2 times 9 is 18. Then subtract: 20 minus 18 is 2.',vis:{t:'eq',l:['= 20 − 18','= 2']}},
 {say:'In a story: 4 juices at 3 dirhams and 2 sandwiches at 8 dirhams cost 12 plus 16, which is 28 dirhams.',vis:{t:'eq',l:['4 × 3 + 2 × 8','= 12 + 16','= 28  (AED 28)']}}
]},

'8.3':{acts:[
 {id:'g6u2-8.3d',t:'Gym membership',min:7,eng:'motion',
  life:'A gym in Dubai charges AED 150 to join plus AED 90 a month. The cost for m months is 90m + 150.',
  cfg:{scene:'meter',p:90,q:150,xmax:12,ymax:1300,int:true,xn:'m',yn:'cost',xL:'months',yL:'cost (AED)',icon:'coin',money:true,sl:{p:[50,150,10],q:[0,300,50]},pName:'AED per month',qName:'joining fee',say:'Press Play: each month adds the same amount to the cost.'},
  ask:['Which part of 90m + 150 is paid only once?','What does m stand for?','Change the monthly fee. What happens to the graph?','Write an expression for a gym with no joining fee and AED 120 a month.'],
  ch:{q:'A swimming club costs AED 200 to join and AED 75 per month. Write the expression and find the cost for 6 months.',a:'75m + 200; 75(6) + 200 = 650, so AED 650.'}},
 {id:'g6u2-8.3e',t:'Boxes of luqaimat',min:6,eng:'cards',
  life:'A café packs luqaimat in boxes with b pieces in each, plus 3 extra pieces on a plate: 4b + 3.',
  cfg:{mode:'bags',coef:4,k:3,var:'b',max:9,unit:'pieces',icon:'date',what:'Each box holds b luqaimat.',say:'Change b, then open the boxes.'},
  ask:['What does b stand for?','Write the total for 4 boxes and 3 extra pieces.','Open the boxes with b = 6. How many pieces?','Why do we write 4b and not b4?'],
  ch:{q:'Write an expression for 5 boxes with b pieces each and 2 extra pieces. Find the total when b = 8.',a:'5b + 2; 5(8) + 2 = 42'}}
],roby:[
 {say:'A variable is a letter that stands for a number we do not know yet.',vis:{t:'big',s:'n = dates in one bag'}},
 {say:'Key words help: more than means add, times means multiply, less than means subtract.',vis:{t:'tab',h:['words','expression'],r:[['5 more than n','n + 5'],['3 times n','3n'],['4 less than n','n − 4'],['n shared by 2','n ÷ 2']]}},
 {say:'A taxi costs 12 dirhams to start plus 2.50 dirhams per kilometre. The fare is 12 plus 2.5 d.',vis:{t:'eq',l:['fare = 12 + 2.5d']}},
 {say:'Careful! 4 less than n is n minus 4, not 4 minus n.',vis:{t:'eq',l:['4 less than n','= n − 4  ✓','≠ 4 − n']}},
 {say:'Try it: 3 bags with n dates each and 5 loose dates make 3 n plus 5.',vis:{t:'eq',l:['3n + 5']}}
]},

'8.4':{acts:[
 {id:'g6u2-8.4d',t:'Summer heat: °C to °F',min:6,eng:'machine',
  life:'UAE summer can reach 45 °C. Many weather apps also show °F using the expression 1.8C + 32.',
  cfg:{rule:'1.8x + 32',show:'× 1.8, then + 32',inputs:[0,25,40,45,-5],min:-10,max:50,step:1,var:'°C',out:'°F',story:'°C in → °F out',say:'Feed in temperatures. Predict each one first.'},
  ask:['Evaluate 1.8C + 32 for C = 0. What does the answer mean?','What is 45 °C in °F?','Why do we multiply before adding 32?','Which input gives 50 °F?'],
  ch:{q:'Evaluate 1.8C + 32 for C = 30.',a:'1.8 × 30 + 32 = 54 + 32 = 86 °F'}},
 {id:'g6u2-8.4e',t:'Road trip: Abu Dhabi to Dubai',min:6,eng:'motion',
  life:'Driving at about 100 km/h, the distance travelled after t hours is 100t. Abu Dhabi to Dubai is roughly 140 km.',
  cfg:{scene:'road',p:100,q:0,xmax:1.5,ymax:160,xn:'t',yn:'distance',xL:'time (h)',yL:'distance (km)',uy:'km',color:'#ffffff',say:'Press Play. Evaluate 100t as the car drives.'},
  ask:['Evaluate 100t for t = 0.5. What does it mean?','How far after 1.2 hours?','About how long to drive 140 km?','Why does the graph start at 0?'],
  ch:{q:'Evaluate 100t for t = 1.25 hours.',a:'125 km'}}
],roby:[
 {say:'To evaluate an expression, replace the variable with its value.',vis:{t:'eq',l:['4x − 3  when  x = 5']}},
 {say:'Substitute 5 for x.',vis:{t:'eq',l:['4x − 3','= 4(5) − 3']}},
 {say:'Multiply first, then subtract: 20 minus 3 is 17.',vis:{t:'eq',l:['= 20 − 3','= 17']}},
 {say:'Formulas are expressions too. Perimeter P equals 2 l plus 2 w. If l is 6 and w is 4, P is 20.',vis:{t:'eq',l:['P = 2(6) + 2(4)','= 12 + 8','= 20']}},
 {say:'A pool has 50 litres plus 20 litres each minute. After 3 minutes it has 110 litres.',vis:{t:'eq',l:['50 + 20t, t = 3','= 50 + 60','= 110 L']}}
]},

'8.5':{acts:[
 {id:'g6u2-8.5d',t:'Global Village family tickets',min:7,eng:'equiv',
  life:'4 family members each pay x for Global Village entry plus AED 5 for a ride: 4(x + 5). Paying separately: 4x + 20.',
  cfg:{pairs:[['4(x + 5)','4x + 20'],['4(x + 5)','4x + 5']],names:['Per person','Separately'],xmin:0,xmax:30,step:1,x0:10,yL:'AED',say:'Move the entry price x. Do both ways always cost the same?'},
  ask:['Do the two lines match for every x?','Why is 4x + 5 wrong?','Use the distributive property to show 4(x + 5) = 4x + 20.','Write an equivalent expression for 6(x + 2).'],
  ch:{q:'Are 5(x + 3) and 5x + 15 equivalent? Test x = 2.',a:'Yes: 5(5) = 25 and 10 + 15 = 25; they are equal for every x.'}},
 {id:'g6u2-8.5e',t:'Supermarket basket: like terms',min:6,eng:'cards',
  life:'A basket has 3 bottles of water, AED 5 of fruit, 2 more bottles and a AED 2 discount: 3x + 5 + 2x − 2 = 5x + 3.',
  cfg:{mode:'combine',terms:[{c:'3',v:'x'},{c:'5'},{c:'2',v:'x'},{c:'-2'}],test:2,story:'x = price of one bottle of water',notes:['Find the like terms.','x-terms together, constants together.','Add the coefficients: 3 + 2 = 5 and 5 − 2 = 3.']},
  ask:['Why do 3x and 2x go together?','What does −2 mean in the story?','Test x = 2 in both forms.','Write a different expression that also equals 5x + 3.'],
  ch:{q:'Simplify 4y − 3 + y + 9.',a:'5y + 6'}}
],roby:[
 {say:'Equivalent expressions give the same value for every value of the variable.',vis:{t:'eq',l:['3(x + 2) = 3x + 6']}},
 {say:'Distributive property: multiply the outside number by each term inside the brackets.',vis:{t:'area',a:'3',parts:[['x',3],['2',1.4]],prods:['3x','6']}},
 {say:'Check with a table: both columns always match.',vis:{t:'tab',h:['x','3(x + 2)','3x + 6'],r:[['1','9','9'],['4','18','18'],['10','36','36']]}},
 {say:'Combine like terms: 2x plus 4x is 6x, and 3 plus 1 is 4.',vis:{t:'eq',l:['2x + 3 + 4x + 1','= 6x + 4']}},
 {say:'Not equivalent: 3 times x plus 2 in brackets, and 3x plus 2. Test x equals 1: you get 9 and 5.',vis:{t:'eq',l:['3(1 + 2) = 9','3(1) + 2 = 5','9 ≠ 5']}}
]}
}});
